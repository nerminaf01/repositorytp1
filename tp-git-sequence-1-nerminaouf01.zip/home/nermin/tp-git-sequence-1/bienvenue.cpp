// TODO Indiquer ce que fait le programme
#include <iostream>

int main()
{
    std::cout << "Bienvenue le monde !" << std::endl;
    std::cout << "Bienvenue dans le programme !\n";
    return 0;
}
